# settings
u_token = "c61e1dc986cd4fc1ff64c895b7d034f1f2f3fafd"
base_url = "https://api.github.com/"
user_name = "vmlankub"
user_mail = "45290401+vmlankub@users.noreply.github.com"
account_name = "urlib"
repo_name = "iCVzr8"
simple_repo_name = "CsVzGTXu"
proxy_repo_name = "sorry"
image_repo_name = "tim"
gen_method = "sha1"

proxies = {"http": "http://127.0.0.1:1080",
           "https": "http://127.0.0.1:1080"}
